function add(str1, str2) {
  return `${str1} ${str2}`;
}

module.exports = {
  add,
};
