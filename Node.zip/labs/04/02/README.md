## Setting up Google OAuth 2.0:

Read the documentation [here](https://support.google.com/cloud/answer/6158849)
